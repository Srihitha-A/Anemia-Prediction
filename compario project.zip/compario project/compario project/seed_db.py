from app import app, db, Product
from scraping.smart_scraper import scrape_live, scrape_product_details
import time
import json

def seed_database(force=False):
    """
    Unified seeding script that crawls multiple categories across all 4 platforms.
    Fetches deep details for each item to make the modal instant.
    """
    categories = [
        "iPhone 15", "Samsung Galaxy S24 Ultra", "MacBook Air M3", "Sony WH-1000XM5",
        "AirPods Pro", "LG OLED TV", "Bose Speaker", "PlayStation 5", "Logitech G Pro",
        "Dell XPS 15", "Canon EOS R5", "Nike Air Jordan",
        "Samsung Front Load Washing Machine", "LG Side by Side Refrigerator", 
        "Dyson V15 Vacuum Cleaner", "Philips Air Fryer", "Haier 1.5 Ton AC",
        "Sony Bravia 55 inch 4K TV", "Asus ROG Zephyrus G14", "Bajaj Mixer Grinder"
    ]
    
    # Fashion and Lifestyle
    fashion_cats = ["Levi's 511 Jeans", "Nike Air Max", "Puma T-Shirt", "Adidas Jacket", "Casio G-Shock"]
    all_cats = categories + fashion_cats
    
    with app.app_context():
        print(f"\n--- [Unified Seeder] Starting Multi-Category Seeding ---")
        
        # Modified: Don't skip entirely if items exist, instead process each category
        # and skip individual items already in DB by link.
        current_count = Product.query.count()
        print(f"   [Seeding] Database currently has {current_count} items.")

        total_added = 0
        for category in all_cats:
            print(f"\n   [Seeding] Scraping Category: '{category}'...")
            try:
                # Use live search results to seed the database
                results = scrape_live(category)
                
                added_for_cat = 0
                for item in results:
                    # Deduplication by link
                    exists = Product.query.filter_by(link=item['link']).first()
                    if not exists:
                        try:
                            # Clean price even during seed
                            price_val = int(float(str(item.get('price', 0)).replace(',', '')))
                            
                            # DEEP SCRAPE FOR SEEDING (Optional: only for top 3 per cat to save time)
                            specs_str = None
                            shipping = "Standard Shipping"
                            if added_for_cat < 3:
                                print(f"      [Seeding] Fetching deep details for: {item['name'][:30]}...")
                                details = scrape_product_details(item['link'], item['platform'])
                                if details.get('specs'):
                                    specs_str = json.dumps(details['specs'])
                                    shipping = details.get('shipping') or details.get('delivery_date') or shipping

                            new_p = Product(
                                name=item['name'],
                                price=price_val,
                                platform=item['platform'],
                                link=item['link'],
                                image=item['image'],
                                search_term=category.lower(),
                                specifications=specs_str,
                                shipping_info=shipping
                            )
                            db.session.add(new_p)
                            added_for_cat += 1
                        except Exception as e: 
                            print(f"      [Seeding] Failed item: {e}")
                            continue
                
                db.session.commit()
                total_added += added_for_cat
                print(f"   [Seeding] Added {added_for_cat} products for '{category}'.")
                
                # Polite delay
                time.sleep(2)
            except Exception as e:
                print(f"   [Seeding] Error in category '{category}': {e}")
                db.session.rollback()
                
        print(f"\n--- [Seeder] SUCCESS. Added {total_added} products. Total in DB: {Product.query.count()} ---")

def seed_hardcoded_reliance():
    # Hardcoded Reliance data for fallback
    # These are some popular products on Reliance Digital (as of early 2026)
    reliance_data = [
        # --- iPhones ---
        {
            "name": "Apple iPhone 15 (Black, 128 GB)",
            "price": 66900,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/apple-iphone-15-128-gb-black/p/493839255",
            "image": "https://www.reliancedigital.in/medias/iPhone-15-Black-128GB-493839255-i-1-1200Wx1200H",
            "search_term": "iphone 15",
            "specifications": json.dumps(["128 GB ROM", "15.49 cm (6.1 inch) Display", "48MP + 12MP | 12MP Front Camera"]),
            "shipping_info": "Delivery by Tomorrow"
        },
        {
            "name": "Apple iPhone 16 (Ultramarine, 128 GB)",
            "price": 79900,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/apple-iphone-16-128-gb-ultramarine/p/494421864",
            "image": "https://www.reliancedigital.in/medias/Apple-iPhone-16-128-GB-Ultramarine-494421864-i-1-1200Wx1200H",
            "search_term": "iphone 16",
            "specifications": json.dumps(["128 GB ROM", "6.1 inch Super Retina XDR", "A18 Chip", "Camera Control"]),
            "shipping_info": "Free Shipping"
        },
        {
            "name": "Apple iPhone 13 (Midnight, 128 GB)",
            "price": 49900,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/apple-iphone-13-128-gb-midnight/p/491997699",
            "image": "https://www.reliancedigital.in/medias/iPhone-13-Midnight-128GB-491997699-i-1-1200Wx1200H",
            "search_term": "iphone 13",
            "specifications": json.dumps(["128 GB ROM", "6.1 inch OLED Display", "A15 Bionic Chip"]),
            "shipping_info": "Standard Delivery"
        },
        # --- Samsung ---
        {
            "name": "Samsung Galaxy S24 Ultra 5G (Titanium Gray, 256 GB)",
            "price": 129999,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/samsung-galaxy-s24-ultra-5g-256-gb-12-gb-ram-titanium-gray-mobile-phone/p/494351912",
            "image": "https://www.reliancedigital.in/medias/Samsung-Galaxy-S24-Ultra-494351912-i-1-1200Wx1200H",
            "search_term": "s24 ultra",
            "specifications": json.dumps(["12 GB RAM | 256 GB ROM", "6.8 inch QHD+ Display", "200MP Camera"]),
            "shipping_info": "Delivery in 2-3 Days"
        },
        {
            "name": "Samsung Galaxy S23 FE 5G (Graphite, 128 GB)",
            "price": 35999,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/samsung-galaxy-s23-fe-5g-128-gb-8-gb-ram-graphite-mobile-phone/p/494225432",
            "image": "https://www.reliancedigital.in/medias/Samsung-Galaxy-S23-FE-494225432-i-1-1200Wx1200H",
            "search_term": "s23 fe",
            "specifications": json.dumps(["8 GB RAM | 128 GB ROM", "50MP Triple Camera", "IP68 Rating"]),
            "shipping_info": "Free Delivery"
        },
        # --- Laptops ---
        {
            "name": "Apple MacBook Air M3 Chip (13.6-inch, 8GB RAM, 256GB SSD, Midnight)",
            "price": 104900,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/apple-macbook-air-m3-chip-13-inch-8-gb-256-gb-ssd-midnight/p/494351645",
            "image": "https://www.reliancedigital.in/medias/Apple-MacBook-Air-M3-494351645-i-1-1200Wx1200H",
            "search_term": "macbook air",
            "specifications": json.dumps(["Apple M3 Chip", "8-Core CPU", "Up to 18 Hours Battery Life"]),
            "shipping_info": "Delivery Today"
        },
        {
            "name": "HP Laptop 15s (12th Gen Intel Core i3, 8GB RAM, 512GB SSD)",
            "price": 34990,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/hp-laptop-15s-fr5007tu/p/493177708",
            "image": "https://www.reliancedigital.in/medias/HP-Laptop-15s-493177708-i-1-1200Wx1200H",
            "search_term": "hp laptop",
            "specifications": json.dumps(["Intel Core i3-1215U", "8 GB RAM", "512 GB SSD", "Windows 11"]),
            "shipping_info": "Free Shipping"
        },
        # --- Audio ---
        {
            "name": "Sony WH-1000XM5 Wireless Noise Cancelling Headphones (Black)",
            "price": 29990,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/sony-wh-1000xm5-wireless-noise-cancelling-headphones-black/p/492850493",
            "image": "https://www.reliancedigital.in/medias/Sony-WH-1000XM5-Headphones-492850493-i-1-1200Wx1200H",
            "search_term": "sony headphones",
            "specifications": json.dumps(["Active Noise Cancellation", "30 Hours Battery", "Touch Controls"]),
            "shipping_info": "Free Shipping"
        },
        {
            "name": "Apple AirPods Pro (2nd Gen) with MagSafe Case (USB-C)",
            "price": 22900,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/apple-airpods-pro-2nd-gen-with-magsafe-case-usb-c-/p/493839352",
            "image": "https://www.reliancedigital.in/medias/AirPods-Pro-2nd-Gen-493839352-i-1-1200Wx1200H",
            "search_term": "airpods pro",
            "specifications": json.dumps(["Active Noise Cancellation", "Transparency Mode", "Spatial Audio"]),
            "shipping_info": "Delivery by Tomorrow"
        },
        # --- TVs ---
        {
            "name": "Sony Bravia 139 cm (55 inch) 4K Ultra HD Smart LED Google TV",
            "price": 57990,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/sony-bravia-139-cm-55-inch-4k-ultra-hd-smart-led-google-tv-kd-55x74l/p/493665842",
            "image": "https://www.reliancedigital.in/medias/Sony-Bravia-55-inch-Google-TV-493665842-i-1-1200Wx1200H",
            "search_term": "sony tv",
            "specifications": json.dumps(["4K Ultra HD", "Google TV", "X1 4K Processor"]),
            "shipping_info": "Standard Delivery"
        },
        # --- ACs ---
        {
            "name": "LG 1.5 Ton 5 Star AI DUAL Inverter Split AC (Copper, 2024 Model)",
            "price": 46990,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/lg-1.5-ton-5-star-ai-dual-inverter-split-ac-rs-q19ynze/p/493664718",
            "image": "https://www.reliancedigital.in/medias/LG-Split-AC-493664718-i-1-1200Wx1200H",
            "search_term": "lg ac",
            "specifications": json.dumps(["1.5 Ton", "5 Star", "AI Dual Inverter", "Copper Condenser"]),
            "shipping_info": "Installation Tomorrow"
        },
        # --- Google Pixel ---
        {
            "name": "Google Pixel 8 (Obsidian, 128 GB)",
            "price": 59900,
            "platform": "Reliance Digital",
            "link": "https://www.reliancedigital.in/google-pixel-8-128-gb-8-gb-ram-obsidian-mobile-phone/p/494225455",
            "image": "https://www.reliancedigital.in/medias/Google-Pixel-8-494225455-i-1-1200Wx1200H",
            "search_term": "google pixel 8",
            "specifications": json.dumps(["8 GB RAM | 128 GB ROM", "6.2 inch Actua Display", "Tensor G3 Chip"]),
            "shipping_info": "Standard Delivery"
        }
    ]

    with app.app_context():
        print("\n   [Seeding] Starting Hardcoded Reliance Seeding...")
        count = 0
        for item in reliance_data:
            exists = Product.query.filter_by(link=item['link']).first()
            if not exists:
                new_p = Product(
                    name=item['name'],
                    price=item['price'],
                    platform=item['platform'],
                    link=item['link'],
                    image=item['image'],
                    search_term=item['search_term'].lower(),
                    specifications=item['specifications'],
                    shipping_info=item['shipping_info']
                )
                db.session.add(new_p)
                count += 1
        db.session.commit()
        print(f"   [Seeding] Added {count} Reliance products to DB.")

if __name__ == "__main__":
    # 1. Run live crawler (optional/standard)
    # seed_database(force=False)
    
    # 2. Run hardcoded Reliance fallback (Integrated)
    seed_hardcoded_reliance()
