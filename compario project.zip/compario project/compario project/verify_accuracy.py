import sys
import os
import time
import io
from scraping.smart_scraper import scrape_live, scrape_product_details

# Ensure UTF-8 output
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def verify_scrapers(query):
    print(f"\n--- SCRAPER ACCURACY TEST: '{query}' ---")
    results = scrape_live(query)
    
    platforms = {}
    for res in results:
        p = res['platform']
        if p not in platforms:
            platforms[p] = []
        platforms[p].append(res)

    print(f"\nFound {len(results)} results across {len(platforms)} platforms.")
    
    report = []
    
    for platform, items in platforms.items():
        print(f"\n[Testing {platform}]")
        success_count = 0
        details_ok = 0
        
        for item in items[:1]: # Test first item from each platform for details
            name = item.get('name')
            price = item.get('price')
            link = item.get('link')
            
            if name and price != "0" and link != "#":
                success_count += 1
                
                print(f"   Testing Details for: {name[:50]}...")
                details = scrape_product_details(link, platform)
                
                has_specs = len(details.get('specs', [])) > 0
                has_rating = details.get('rating') not in ["N/A", "", None]
                has_shipping = details.get('shipping') or details.get('delivery_date')
                has_warranty = details.get('warranty') and details.get('warranty') != "No Warranty Info"
                
                if has_specs and has_rating and has_shipping and has_warranty:
                    details_ok += 1
                    print(f"      [OK] Details OK (Specs: {len(details['specs'])}, Rating: {details['rating']}, Shipping: {details.get('shipping')}, Warranty: {details.get('warranty')})")
                else:
                    print(f"      [MISSING] Specs={has_specs}, Rating={has_rating}, Shipping={has_shipping}, Warranty={has_warranty}")
                    if not has_warranty: print(f"         Warranty Value: {details.get('warranty')}")
        
        report.append({
            "platform": platform,
            "results_found": len(items),
            "valid_basic_info": success_count > 0,
            "full_details_ok": details_ok > 0
        })

    print("\n--- FINAL ACCURACY REPORT ---")
    print(f"{'Platform':<20} | {'Results':<10} | {'Basic Info':<12} | {'Mandatory Details':<20}")
    print("-" * 70)
    for r in report:
        bi = "PASS" if r['valid_basic_info'] else "FAIL"
        md = "PASS" if r['full_details_ok'] else "FAIL"
        print(f"{r['platform']:<20} | {r['results_found']:<10} | {bi:<12} | {md:<20}")

def verify_database():
    from app import app, db, Product
    print(f"\n--- DATABASE FALLBACK CHECK ---")
    with app.app_context():
        # 1. Total Reliance Items
        rel_count = Product.query.filter(Product.platform == "Reliance Digital").count()
        print(f"   [Reliance DB] Total items: {rel_count}")
        
        # 2. Test Fallback Query
        test_q = "iphone"
        query_words = [test_q]
        search_filter = Product.name.ilike(f"%{query_words[0]}%")
        res = Product.query.filter(search_filter).all()
        print(f"   [Query Test] Results for '{test_q}': {len(res)}")
        for p in res[:3]:
            print(f"      - {p.name} ({p.platform})")
            
    return rel_count > 0

if __name__ == "__main__":
    test_query = "iphone 15"
    if len(sys.argv) > 1:
        test_query = " ".join(sys.argv[1:])
    
    # Run Scraper Tests
    verify_scrapers(test_query)
    
    # Run Database Tests
    db_ok = verify_database()
    
    # Final Result
    print(f"\n{'='*50}")
    status = "SUCCESS" if db_ok else "WARNING (DB EMPTY)"
    print(f"OVERALL VERIFICATION STATUS: {status}")
    print(f"{'='*50}")
