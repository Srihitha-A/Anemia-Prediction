from playwright.sync_api import sync_playwright
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

def clean_price(text):
    if not text: return "0.00"
    # Remove commas and currency symbols
    cleaned = text.replace(',', '').replace('₹', '').replace('Rs.', '').strip()
    
    # Try to find a decimal number (e.g. 40999.00)
    match = re.search(r'(\d+\.\d{2})', cleaned)
    if match:
        return match.group(1)
    
    # If no decimal, find the first sequence of numbers and add .00
    nums = re.findall(r'\d+', cleaned)
    if nums:
        # Avoid joining MRP and Discount numbers (e.g. "69,900 79,900 15%")
        return f'{nums[0]}.00'
    
    return "0.00"

def get_clean_name(name):
    """
    Strips technical specs in parentheses and common patterns like GB, RAM, Color etc.
    Used for a cleaner UI on product cards.
    """
    if not name: return ""
    # Remove everything in parentheses
    name = re.sub(r'\(.*?\)', '', name)
    # Remove common patterns
    patterns = [
        r'\d+\s*GB', r'\d+\s*TB', r'\d+\s*GB\s*RAM', r'\d+\s*MB',
        r'(?i)black', r'(?i)white', r'(?i)blue', r'(?i)silver', r'(?i)gold', r'(?i)grey', r'(?i)gray',
        r'(?i)red', r'(?i)green', r'(?i)yellow', r'(?i)purple', r'(?i)pink',
        r'(?i)starlight', r'(?i)midnight', r'(?i)natural titanium', r'(?i)blue titanium',
        r'(\d+)\s*cm', r'(\d+)\s*inch', r'(\d+)\s*mm',
        r'\d+\s*mAh', r'\d+\s*W', r'\d+\s*Hz'
    ]
    for pattern in patterns:
        name = re.sub(pattern, '', name)
    # Remove extra spaces and punctuation at the end
    name = re.sub(r'\s{2,}', ' ', name)
    return name.strip(', -').strip()

def scrape_amazon(query, results_list, lock):
    """Scrape Amazon with optimized timeouts and robust selectors"""
    query_words = query.lower().split()
    
    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                viewport={'width': 1366, 'height': 768}, # Increased for Reliance & desktop layouts
                extra_http_headers={
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Referer': 'https://www.google.com/'
                }
            )
            page = context.new_page()
            
            url = f"https://www.amazon.in/s?k={query.replace(' ', '+')}"
            print(f"[Amazon] Visiting {url}")
            
            try:
                page.goto(url, timeout=40000, wait_until="domcontentloaded")
                # Random interaction to mimic human
                page.mouse.wheel(0, 300)
                page.wait_for_timeout(2000)
            except Exception as e:
                print(f"[Amazon] Goto Warning: {e}")

            try:
                page.wait_for_selector('div[data-component-type="s-search-result"]', timeout=8000)
            except:
                print("[Amazon] Timeout waiting for results")

            cards = page.query_selector_all('div[data-component-type="s-search-result"], .s-result-item[data-asin]')
            print(f"   [Amazon] Found {len(cards)} raw cards.")
            
            for card in cards[:15]: # Increased from 8
                try:
                    # Title Fallbacks
                    title_el = card.query_selector("h2 span, h2 a span, .a-size-medium, .a-size-base-plus")
                    
                    # Price Fallbacks
                    price_el = card.query_selector(".a-price-whole") or card.query_selector(".a-offscreen")
                    
                    img_el = card.query_selector("img.s-image")
                    link_el = card.query_selector("a.a-link-normal.s-no-outline, h2 a.a-link-normal, a.a-link-normal")
                    
                    if title_el:
                        title = (title_el.get_attribute("title") or title_el.inner_text()).strip()
                        if not title or "..." in title:
                            candidate = link_el.get_attribute("title") or img_el.get_attribute("alt") if (link_el and img_el) else None
                            if candidate and len(candidate) > len(title):
                                title = candidate.strip()
                        
                        price = "0"
                        if price_el:
                            price_text = price_el.inner_text() or price_el.get_attribute("textContent")
                            price = clean_price(price_text)
                        
                        if price == "0" or price == "0.00":
                             # Try alternate price
                             alt_price = card.query_selector(".a-price .a-offscreen")
                             if alt_price: price = clean_price(alt_price.inner_text())
                        
                        if price == "0" or price == "0.00":
                            continue

                        significant_words = [w for w in query_words if len(w) > 2]
                        if significant_words and not any(w in title.lower() for w in significant_words):
                            continue
                        
                        image = "https://placehold.co/400?text=No+Image"
                        if img_el:
                            # Added more data-attributes used by Amazon for lazy loading
                            image = img_el.get_attribute("src") or img_el.get_attribute("data-src") or \
                                    img_el.get_attribute("data-lazy-src") or img_el.get_attribute("data-a-dynamic-image") or image
                            
                            if image.startswith("{"): # Amazon dynamic image JSON
                                try:
                                    import json
                                    img_dict = json.loads(image)
                                    image = list(img_dict.keys())[0] if img_dict else image
                                except: pass
                                    
                            srcset = img_el.get_attribute("srcset")
                            if srcset:
                                image = srcset.split(",")[0].split(" ")[0]
                        
                        rel_link = link_el.get_attribute("href") if link_el else "#"
                        # Filter out sponsored / ad links which are slow or redirect
                        if any(x in rel_link for x in ["/slredirect/", "aax-", "/sspa/click", "ad-", "sponsored"]):
                            continue
                        
                        link = "https://www.amazon.in" + rel_link if rel_link.startswith('/') else rel_link
                        
                        # Clean Amazon Link
                        asin_match = re.search(r'/dp/([A-Z0-9]{10})', link)
                        if asin_match:
                            link = f"https://www.amazon.in/dp/{asin_match.group(1)}"
                        
                        # Extraction: Rating & Shipping (Fast Search Page version)
                        rating = ""
                        rating_el = card.query_selector("a[aria-label*='out of 5 stars'], [data-cy='reviews-block'] i, .a-icon-star-small")
                        if rating_el:
                            rating_txt = (rating_el.get_attribute("aria-label") or rating_el.inner_text() or "").split(' ')[0]
                            # Clean numeric rating
                            match = re.search(r'(\d+\.\d+|\d+)', rating_txt)
                            rating = match.group(1) if match else rating_txt

                        shipping = ""
                        ship_el = card.query_selector("[data-cy='delivery-block'], .s-delivery-instructions-style, span[aria-label*='delivery']")
                        if ship_el:
                            shipping_raw = ship_el.inner_text().strip().replace('FREE delivery', 'Free Delivery')
                            # Clean "by [Date]" if possible
                            if 'by' in shipping_raw:
                                shipping = f"Delivery {shipping_raw.split('by')[-1].strip()}"
                            elif 'tomorrow' in shipping_raw.lower():
                                shipping = "Delivery Tomorrow"
                            elif 'today' in shipping_raw.lower():
                                shipping = "Delivery Today"
                            elif 'in' in shipping_raw.lower():
                                shipping = shipping_raw
                            else:
                                shipping = shipping_raw
                        
                        # Amazon tags (e.g. "Limited time deal")
                        tag_el = card.query_selector(".s-label-popover-default")
                        if tag_el:
                            shipping = f"{tag_el.inner_text().strip()} | {shipping}"

                        with lock:
                            results_list.append({
                                "name": title,
                                "price": price,
                                "image": image,
                                "link": link,
                                "platform": "Amazon",
                                "rating": rating,
                                "shipping": shipping
                            })
                except: continue
            
            browser.close()
        except Exception as e:
            print(f"   [Amazon] Error: {e}")

def scrape_flipkart(query, results_list, lock):
    """Scrape Flipkart with updated selectors for late 2025 layout"""
    query_words = query.lower().split()
    
    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                viewport={'width': 1920, 'height': 1080}
            )
            page = context.new_page()
            
            url = f"https://www.flipkart.com/search?q={query.replace(' ', '+')}"
            print(f"[Flipkart] Visiting {url}")
            page.goto(url, timeout=45000) # Increased timeout
            
            try:
                # Updated main container selectors from LIVE audit
                # a.k7wcnx and div.cPHDOP are the most common in current layout
                page.wait_for_selector('a.k7wcnx, div.cPHDOP, div.lvJbLV, div._1AtVbE', timeout=8000)
            except: pass

            # Extended selectors for latest layout audit
            cards = page.query_selector_all('a.k7wcnx, div.cPHDOP, div.lvJbLV, div.jIjQ8S, div._1AtVbE, div._2kHMtA') 
            print(f"   [Flipkart] Found {len(cards)} raw cards.")
            
            for card in cards[:15]: # Increased from 8
                try:
                    # div.RG5Slk and div.Kz9XN9 are the latest primary title selectors
                    title_el = card.query_selector("div.RG5Slk, div.Kz9XN9, .KzDlHZ, a.s1Q9rs, .W_F_yC, .wE969L, div._4rR01T")
                    price_el = card.query_selector(".Nx9bqj, .DeU9vF, .hZ3P6w, .Nx9W0j, ._30jeq3")
                    img_el = card.query_selector("img.UCc1lI, img.DByoQZ, img.DByoH4, img._396cs4, img._2_S_F")
                    link_el = card.query_selector("a.k7wcnx, a.CGtC98, a._2vp_6Z, a._1fQZEK") or (card if card.evaluate('el => el.tagName === "A"') else card.query_selector("a"))

                    if title_el:
                        title = (title_el.get_attribute("title") or title_el.inner_text()).strip()
                        if not title or "..." in title:
                            candidate = (link_el.get_attribute("title") if link_el else None) or (img_el.get_attribute("alt") if img_el else None)
                            if candidate and len(candidate) > len(title):
                                title = candidate.strip()
                        
                        # Strip ratings and reviews if they bled into the title
                        title = re.sub(r' \d+\.\d+.* Ratings.*| \d+ Ratings.*| \d+ Reviews.*', '', title).strip()
                        
                        price = "0"
                        if price_el:
                            price = clean_price(price_el.inner_text())
                        
                        # Relevancy and Bleed Checks
                        significant_words = [w for w in query_words if len(w) > 2]
                        if significant_words and not any(w in title.lower() for w in significant_words):
                            continue
                            
                        bleed_words = {'watch', 'case', 'cover', 'band', 'strap', 'screen guard', 'tempered'}
                        if not any(w in query.lower() for w in bleed_words) and any(w in title.lower() for w in bleed_words):
                            continue
                        
                        # Robust Image capture
                        image = "https://placehold.co/400?text=No+Image"
                        if img_el:
                            image = img_el.get_attribute("src") or img_el.get_attribute("data-src") or \
                                    img_el.get_attribute("data-lazy-src") or img_el.get_attribute("srcset") or image
                            if "," in image: # If it's a srcset
                                image = image.split(",")[0].split(" ")[0]
                        
                        # Rating & Shipping
                        rating = ""
                        # Flipkart search page selectors for ratings (wide variety)
                        rating_el = card.query_selector("div[class*='_3LWZlK'], .IHXGEy, .XQD09Y, ._1w7V93, span[id*='productRating'], ._5O_990, ._2beN3Z")
                        if rating_el: rating = rating_el.inner_text().strip()
                        
                        shipping = ""
                        # Flipkart search page selectors for delivery (wide variety)
                        # Added more generic classes found in recent 2026 captures
                        # Flipkart often shows delivery info in a div or span near the price or rating
                        ship_el = card.query_selector("div[class*='_3tc89B'], ._1NIn1W, ._3X9uXv, ._16p64S, ._2-uHBa, [data-id*='delivery'], ._20v8of, [class*='delivery'], ._3G9_3S, ._2beN3Z + div, .y_69as, ._2beN3Z + span, ._1-860U, ._3X9uXv, ._2T_F8B, ._3G9_3S, ._2beN3Z + div, ._78iS6w, ._1NIn1W, .c-296587")
                        if not ship_el:
                            # Try to find any text containing 'Delivery' or 'by' or 'Get it'
                            # Using XPath-like class search for reliability
                            ship_el = card.query_selector("div:has-text('Delivery'), span:has-text('Delivery'), div:has-text('by'), span:has-text('by'), div:has-text('Get it'), span:has-text('Get it'), .f_5_667, ._3LWZlK + div, ._20v8of div, ._1xJ78M, ._3G9_3S")
                        
                        if ship_el: 
                             shipping_text = ship_el.inner_text().strip()
                             # Clean Flipkart shipping text (remove 'Free' or 'Secure' or 'FREE' prefixes if they hide dates)
                             # Keep only the date-related part if possible
                             shipping_text = re.sub(r'Secure delivery|Free delivery|FREE delivery|Get it by', '', shipping_text, flags=re.I).strip()
                             if shipping_text:
                                 # Split by newline and take first line to avoid giant blocks
                                 shipping_text = shipping_text.split('\n')[0].strip()
                                 if any(x in shipping_text.lower() for x in ["delivery", "by", "tomorrow", "day", "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]):
                                     shipping = shipping_text if "Delivery" in shipping_text or "by" in shipping_text.lower() else f"Delivery {shipping_text}"
                                 elif len(shipping_text) < 40:
                                     shipping = f"Delivery {shipping_text}"
                             else:
                                 shipping = "Free Delivery" # Fallback if element found but text empty after cleaning
                        
                        # New: Extract Search-Page Specs for Flipkart (Bullets)
                        specs = []
                        spec_list = card.query_selector("ul.HwRTzP, ul._1xgLHA")
                        if spec_list:
                            bullets = spec_list.query_selector_all("li")
                            specs = [li.inner_text().strip() for li in bullets[:3]]

                        rel_link = link_el.get_attribute("href") if link_el else "#"
                        link = "https://www.flipkart.com" + rel_link if rel_link.startswith('/') else rel_link
                        
                        with lock:
                            results_list.append({
                                "name": title, 
                                "price": price,
                                "image": image, 
                                "link": link, 
                                "platform": "Flipkart",
                                "rating": rating,
                                "shipping": shipping,
                                "specs": specs
                            })
                except: continue
            
            browser.close()
        except Exception as e:
            print(f"   [Flipkart] Error: {e}")

def scrape_vijay_sales(query, results_list, lock):
    """Scrape Vijay Sales with newly verified selectors and robust timeouts."""
    query_words = query.lower().split()
    
    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            )
            page = context.new_page()
            
            url = f"https://www.vijaysales.com/search-listing?q={query.replace(' ', '%20')}"
            print(f"   [Vijay Sales] Visiting {url}")
            page.goto(url, timeout=30000)
            
            # Use newly verified selectors from subagent audit
            try:
                # Vijay Sales recently changed structure: Click search trigger first
                trigger = page.query_selector(".input-result")
                if trigger:
                    trigger.click()
                    page.wait_for_selector(".searchContainer__searchAndInput--searchInputBox", timeout=5000)
                    search_box = page.query_selector(".searchContainer__searchAndInput--searchInputBox")
                    if search_box:
                        search_box.fill(query)
                        search_box.press("Enter")
                        page.wait_for_load_state("domcontentloaded")
                
                # Wait for results or empty state
                page.wait_for_selector('.product-card, .product-item, .no-results, .search-not-found', timeout=10000)
            except:
                print(f"   [Vijay Sales] Timeout waiting for results. URL: {page.url}")

            # Cards
            cards = page.query_selector_all('.product-card')
            print(f"   [Vijay Sales] Found {len(cards)} items.")
            
            for card in cards[:15]:
                try:
                    name_el = card.query_selector(".product-card__title, .product-name")
                    price_el = card.query_selector(".product-card__price, .discountedPrice")
                    img_el = card.query_selector(".product__image, img")
                    link_el = card.query_selector("a")
                    
                    if name_el and price_el:
                        name = name_el.inner_text().strip()
                        
                        # Accuracy: Strict Relevancy Check
                        name_low = name.lower()
                        sig_words = [w for w in query_words if len(w) > 2]
                        if sig_words and not any(sw in name_low for sw in sig_words):
                            continue
                        
                        price = clean_price(price_el.inner_text())
                        image = "https://placehold.co/400?text=Vijay+Sales"
                        if img_el:
                            src = img_el.get_attribute("src") or img_el.get_attribute("data-src")
                            if src:
                                if src.startswith("//"): image = "https:" + src
                                elif not src.startswith("http"): image = "https://www.vijaysales.com" + src
                                else: image = src
                        
                        rel_link = link_el.get_attribute("href") if link_el else "#"
                        link = "https://www.vijaysales.com" + rel_link if rel_link.startswith('/') else rel_link
                        
                        # EXTRACTION: Rating & Shipping
                        rating = ""
                        rating_el = card.query_selector(".product__title--reviews-star, .rating-star")
                        if rating_el:
                            # Try to extract rating from style or text
                            rating_style = rating_el.get_attribute("style")
                            if rating_style and "--rating" in rating_style:
                                rating = re.search(r'--rating:\s*([\d.]+)', rating_style).group(1)
                            else:
                                rating = rating_el.inner_text().strip()

                        shipping = ""
                        ship_el = card.query_selector(".delivery-info, .delivery, .product-item-delivery")
                        if ship_el: 
                            shipping = ship_el.inner_text().strip()
                            if not any(x in shipping.lower() for x in ["delivery", "by", "in"]):
                                shipping = f"Delivery {shipping}"

                        with lock:
                            results_list.append({
                                "name": name,
                                "price": price,
                                "image": image,
                                "link": link,
                                "platform": "Vijay Sales",
                                "rating": rating,
                                "shipping": shipping
                            })
                except: continue
                
            browser.close()
        except Exception as e:
            print(f"   [Vijay Sales] Error: {e}")

import time

def scrape_reliance_digital(query, results_list, lock):
    """Scrape Reliance Digital with optimized navigation and robust selectors"""
    query_words = query.lower().split()
    
    with sync_playwright() as p:
        try:
            # Browser Setup
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
                viewport={'width': 1920, 'height': 1080}
            )
            page = context.new_page()
            page.set_default_timeout(50000)
            
            has_cards = False
            
            # Priority 1: Interactive Home Search
            try:
                print(f"   [Reliance] Navigating Home...")
                page.goto("https://www.reliancedigital.in/", wait_until="domcontentloaded", timeout=30000)
                page.wait_for_timeout(4000) # Wait for potential popups
                
                inp_sel = "input.search-input, input[aria-label*='Search']"
                if page.query_selector(inp_sel):
                    page.click(inp_sel, force=True)
                    page.keyboard.type(query, delay=60)
                    page.keyboard.press("Enter")
                    
                    try:
                        page.wait_for_selector('.product-card, .sp__product, .listing-item', timeout=20000)
                        has_cards = True
                    except:
                        pass
            except Exception as e:
                print(f"   [Reliance] Home search error: {e}")

            # Priority 2: Direct URL Fallback
            if not has_cards:
                url = f"https://www.reliancedigital.in/products?q={query.replace(' ', '%20')}&page_no=1&page_size=12&page_type=number"
                print(f"   [Reliance] Direct URL attempt...")
                try:
                    page.goto(url, wait_until="domcontentloaded", timeout=30000)
                    page.wait_for_selector('.product-card, .sp__product', timeout=15000)
                    has_cards = True
                except: 
                    pass

            if not has_cards:
                print(f"   [Reliance] 0 results found.")
                browser.close()
                return

            # Scroll for images
            page.evaluate("window.scrollTo(0, 1000)")
            page.wait_for_timeout(4000)
            page.evaluate("window.scrollTo(0, 2000)")
            page.wait_for_timeout(2000)

            # Precise Extraction with icon filtering
            data = page.evaluate("""() => {
                const items = [];
                const cards = document.querySelectorAll('.product-card, .sp__product, .listing-item, [class*="product-card"]');
                
                cards.forEach(card => {
                    const nameEl = card.querySelector('.product-card-title, .sp__name, .name, .product-title');
                    const priceEl = card.querySelector('.price-container .price, .sp__price, .price');
                    const linkEl = card.querySelector('a[href*="/p/"], a[href*="/product/"], a');
                    
                    let imageUrl = null;
                    const imgNodes = card.querySelectorAll('img');
                    for (let img of imgNodes) {
                        let src = img.src || img.getAttribute('data-src') || img.getAttribute('srcset');
                        // Exclude icons, theme assets, and SVGs. Prioritize product CDN images.
                        if (src && !src.includes('theme/assets') && !src.includes('.svg') && (src.includes('products') || src.includes('medias'))) {
                            imageUrl = src;
                            break;
                        }
                    }
                    
                    if (nameEl && priceEl && linkEl) {
                        items.push({
                            name: nameEl.innerText.trim(),
                            price: priceEl.innerText.trim(),
                            image: imageUrl,
                            link: linkEl.getAttribute('href')
                        });
                    }
                });
                return items;
            }""")

            added_count = 0
            seen_links = set()
            for item in data:
                try:
                    name = item['name']
                    if not any(word in name.lower() for word in query.lower().split() if len(word) > 2):
                        continue

                    link = item['link']
                    if not link.startswith("http"): 
                        link = "https://www.reliancedigital.in" + (link if link.startswith("/") else "/" + link)
                    
                    if link in seen_links: continue
                    seen_links.add(link)

                    price = clean_price(item['price'])
                    image = item.get('image')
                    if not image or "data:image" in image or ".svg" in image or "theme/assets" in image:
                        image = "https://placehold.co/400?text=Reliance"
                    elif not image.startswith("http"): 
                        image = "https://www.reliancedigital.in" + (image if image.startswith("/") else "/" + image)

                    with lock:
                        results_list.append({
                            "name": name, "price": price, "image": image, "link": link,
                            "platform": "Reliance Digital", "rating": "", "shipping": ""
                        })
                        added_count += 1
                    if added_count >= 15: break
                except: continue

            browser.close()
            print(f"   [Reliance] Success: Found {added_count} products with images.")
        except Exception as e:
            print(f"   [Reliance] Scraper error: {e}")
def scrape_ajio(query, results_list, lock):

    """Scrape Ajio for fashion results"""
    query_words = query.lower().split()
    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                viewport={'width': 1920, 'height': 1080}
            )
            page = context.new_page()
            
            url = f"https://www.ajio.com/search/?text={query.replace(' ', '%20')}"
            print(f"[Ajio] Visiting {url}")
            page.goto(url, timeout=60000, wait_until="domcontentloaded")
            
            try:
                # Ajio often uses 'rilrtl-products-list__item' for results
                page.wait_for_selector('.item, .rilrtl-products-list__item, [data-test="product-card"]', timeout=20000)
            except: 
                print("[Ajio] Timeout waiting for grid")
            
            # Scroll to trigger lazy loading
            page.evaluate("window.scrollBy(0, 500)")
            page.wait_for_timeout(5000)
            
            cards = page.query_selector_all('.item, .rilrtl-products-list__item, [data-test="product-card"]')
            print(f"   [Ajio] Found {len(cards)} items.")
            
            count = 0
            for card in cards[:15]: # Increased from 8
                try:
                    # Brand + Name
                    brand_el = card.query_selector('.brand strong')
                    name_el = card.query_selector('.nameCls, .name')
                    price_el = card.query_selector('.price strong, .price')
                    img_el = card.query_selector('img.rilrtl-lazy-img, img')
                    link_el = card.query_selector('a.rilrtl-products-list__link, a')
                    
                    if name_el and price_el:
                        brand = brand_el.inner_text().strip() if brand_el else ""
                        name = (brand + " " + name_el.inner_text()).strip()
                        price = clean_price(price_el.inner_text())
                        
                        # Robust Image capture
                        image = "https://placehold.co/400?text=Ajio"
                        if img_el:
                            image = img_el.get_attribute("src") or img_el.get_attribute("data-src") or img_el.get_attribute("data-lazy-src") or image
                            srcset = img_el.get_attribute("srcset")
                            if srcset:
                                image = srcset.split(",")[0].split(" ")[0]
                        
                        rel_link = link_el.get_attribute("href") if link_el else "#"
                        link = "https://www.ajio.com" + rel_link if rel_link.startswith('/') else rel_link
                        
                        with lock:
                            results_list.append({
                                "name": name,
                                "price": price,
                                "image": image,
                                "link": link,
                                "platform": "Ajio"
                            })
                        count += 1
                        if count >= 8: break
                except: continue
            browser.close()
        except Exception as e:
            print(f"   [Ajio] Error: {e}")

def get_category(query):
    """
    Identifies the category of the search query to optimize platform selection.
    """
    query_low = query.lower()
    electronics_keywords = [
        'phone', 'iphone', 'samsung', 'mobile', 'laptop', 'macbook', 'dell', 'hp', 'asus', 'acer', 
        'headphone', 'earphone', 'airpod', 'sony', 'boat', 'speaker', 'tv', 'oled', 'lg', 'monitor', 
        'camera', 'canon', 'nikon', 'playstation', 'ps5', 'xbox', 'nintendo', 'mouse', 'keyboard', 
        'ram', 'ssd', 'hard disk', 'refrigerator', 'fridge', 'washing machine', 'ac', 'microwave',
        'earbuds', 'tablet', 'ipad', 'kindle', 'printer', 'router', 'smartwatch'
    ]
    
    fashion_keywords = [
        'shirt', 'tshirt', 'jeans', 'pant', 'shoe', 'nike', 'adidas', 'puma', 'watch', 'sunglass', 
        'bag', 'jacket', 'coat', 'saree', 'kurta', 'dress', 'top', 'kurti', 'heels', 'sneakers',
        'trousers', 'handbag', 'wallet', 'belt', 'jewelry', 'skirt', 'wear'
    ]
    
    if any(k in query_low for k in electronics_keywords):
        return 'electronics'
    if any(k in query_low for k in fashion_keywords):
        return 'fashion'
    return 'general'

def scrape_live(query):
    """
    Parallel scraping across all target platforms with smart categorization.
    """
    print(f"\n--- [Backend Check] Starting PARALLEL Scraping for: '{query}' ---")
    
    results = []
    lock = threading.Lock()
    category = get_category(query)
    
    tasks = []
    # Always include Amazon and Flipkart
    tasks.append((scrape_amazon, "Amazon"))
    tasks.append((scrape_flipkart, "Flipkart"))
    
    # Category based routing
    if category == 'electronics' or category == 'general' or category == 'fashion':
        tasks.append((scrape_vijay_sales, "Vijay Sales"))
        tasks.append((scrape_reliance_digital, "Reliance Digital"))
    
    # 15s Global Search Timeout Overhaul
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {
            executor.submit(func, query, results, lock): platform 
            for func, platform in tasks
        }
        
        # Wait for all tasks with a hard cutoff (Increased to 45s for Reliance/Vijay Sales redirects)
        import concurrent.futures
        done, not_done = concurrent.futures.wait(futures, timeout=45)
        
        for future in done:
            platform = futures[future]
            try:
                future.result()
            except Exception as e:
                print(f"   [{platform}] Error: {e}")
        
        for future in not_done:
            platform = futures[future]
            print(f"   [{platform}] Timed out after 25s. Skipping slow results.")

    # Sort results by price
    try:
        results.sort(key=lambda x: int(float(clean_price(str(x.get('price', '999999'))))))
    except: pass

    print(f"[Smart Scraper] Found {len(results)} items in PARALLEL mode ({category} search).")
    
    # Sort results by price (Low to High)
    def get_price_val(item):
        try:
            p = str(item.get('price', '0')).replace(',', '').replace('₹', '').replace('Rs.', '').strip()
            return float(p) if p and p != '0.00' else float('inf')
        except:
            return float('inf')
            
    results.sort(key=get_price_val)
    return results

def scrape_product_details(url, platform):
    """
    Scrapes detailed technical specs and shipping info from a specific product URL.
    Returns a dictionary of features and delivery info.
    OPTIMIZED for speed: Blocks images/CSS and uses fast wait states.
    """
    print(f"[Smart Scraper] Fetching detailed specs from: {url[:50]}... ({platform})")
    
    with sync_playwright() as p:
        try:
            # Launch with faster args
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            page = context.new_page()
            
            # CRITICAL: Block heavy resources for "immediate" loading
            page.route("**/*.{png,jpg,jpeg,svg,webp,woff2}", lambda route: route.abort())
            
            try:
                page.goto(url, timeout=20000, wait_until="domcontentloaded")
                # Scroll slightly to trigger lazy spec tables
                page.evaluate("window.scrollBy(0, 800)")
                # Explicit fast-wait for any common spec table
                page.wait_for_selector('.prodDetTable, #productDetails_techSpec_section_1, #detailBullets_feature_div, ._14_N6K, table.n7infM, .product-specifications, #specification, .accordionsinglepanel', timeout=8000)
            except: 
                pass 
            
            details = {
                "specs": [],
                "shipping": "Delivery info pending",
                "delivery_date": "",
                "rating": "N/A",
                "warranty": "No Warranty Info"
            }
            
            # Immediate extraction after load
            if platform == "Amazon":
                # Rating - Updated selectors
                rating_el = page.query_selector("span.a-icon-alt, #acrPopover, #averageCustomerReviews .a-size-base")
                if rating_el:
                    details["rating"] = rating_el.inner_text().strip().split(' ')[0]
                
                # Shipping / Delivery Date - Updated selectors
                ship_el = page.query_selector("span[data-atf-delivery-extra], #mir-layout-DELIVERY_BLOCK-slot-PRIMARY_DELIVERY_MESSAGE_ID, #upsell-message, #price-shipping-message, .a-size-base.a-color-secondary")
                if ship_el:
                    details["delivery_date"] = ship_el.inner_text().strip().replace('\n', ' ')
                    if "delivery" in details["delivery_date"].lower():
                         details["shipping"] = details["delivery_date"]
                
                # Specs (Technical Details Table or Bullets)
                rows = page.query_selector_all("#productDetails_techSpec_section_1 tr, .prodDetTable tr, #technicalSpecifications_feature_div tr, .a-keyvalue tr")
                for row in rows[:25]:
                    text = row.inner_text().replace('\n', ': ').strip()
                    if text and ':' in text:
                        details["specs"].append(text)
                
                if not details["specs"]:
                    bullets = page.query_selector_all("#detailBullets_feature_div li, #feature-bullets li span, .a-list-item")
                    for b in bullets[:15]:
                        txt = b.inner_text().strip()
                        if len(txt) > 20 and ':' in txt: details["specs"].append(txt)

                # Warranty - Amazon (Stronger search)
                warranty_patterns = ["#warranty", "#product-warranty", ".warranty-description", "#service-and-support"]
                for pat in warranty_patterns:
                    w_el = page.query_selector(pat)
                    if w_el:
                        details["warranty"] = w_el.inner_text().strip()
                        break
                
                if details["warranty"] == "No Warranty Info":
                    all_text = page.evaluate("() => document.body.innerText")
                    w_match = re.search(r'(?i)(\d+\s*(year|month)\s*manufacturer\s*warranty|\d+\s*(year|month)\s*warranty|warranty:\s*(\d+\s*year)|brand\s*warranty\s*of\s*\d+\s*year)', all_text)
                    if w_match:
                        details["warranty"] = w_match.group(0)
                    else:
                        for b in details["specs"]:
                            if "warranty" in b.lower() and ":" in b:
                                details["warranty"] = b
                                break

            elif platform == "Flipkart":
                # Rating - Updated selectors
                rating_el = page.query_selector(".IHXGEy, ._3LWZlK, ._3K-o9B")
                if rating_el: details["rating"] = rating_el.inner_text().strip()
                
                # Shipping / Delivery - Updated selectors
                ship_el = page.query_selector(".HZ0E6r, .Y8v9H0, ._3X9uXv, ._1NIn1W")
                if ship_el: details["shipping"] = ship_el.inner_text().strip().replace('\n', ' ')
                
                # Specs - Updated selectors (table.n7infM is the primary spec table)
                rows = page.query_selector_all("table.n7infM tr, ._14_N6K tr, ._21lOfd")
                for row in rows[:20]:
                    text = row.inner_text().strip().replace('\n', ': ')
                    if text and ':' in text:
                        details["specs"].append(text)

                # Warranty - Flipkart
                w_el = page.query_selector("div._3hWbT4, div._352bdz, .warranty-text")
                if w_el:
                    details["warranty"] = w_el.inner_text().strip()
                else:
                    for s in details["specs"]:
                        if "warranty" in s.lower():
                            details["warranty"] = s
                            break

            elif platform == "Reliance Digital":
                # Rating - Updated selectors from audit
                page.wait_for_timeout(2000) 
                rating_el = page.query_selector(".rd-feedback-service-average-rating-total-count, .rd-feedback-service-average-rating-section, .avg-rating, .sp__rating, .pdp__rating")
                if rating_el: 
                    details["rating"] = rating_el.inner_text().strip()
                
                # Shipping / Delivery - Updated selectors
                # Shipping / Delivery - Updated selectors from 2026 Audit
                # Reliance often hides delivery info behind a pincode, but sometimes it shows "FREE Delivery"
                ship_el = page.query_selector("h5.delivery-section--header, .feature-text[aria-label='Free Shipping'], .delivery-info, .pdp__delivery, .sp__delivery, .delivery-section")
                if ship_el: 
                    details["shipping"] = ship_el.inner_text().strip().replace('\n', ' ')
                
                # If shipping is still empty, look for any 'FREE Delivery by' text
                if not details["shipping"] or details["shipping"] == "Delivery info pending":
                    delivery_txt = page.evaluate("""() => {
                        const el = Array.from(document.querySelectorAll('*')).find(el => el.children.length === 0 && (el.textContent.includes('Delivery by') || el.textContent.includes('Get it by')));
                        return el ? el.innerText.trim() : null;
                    }""")
                    if delivery_txt:
                        details["shipping"] = delivery_txt

                # Warranty - Reliance (Found via audit)
                warranty_el = page.query_selector(".feature-text[aria-label*='Warranty']")
                if warranty_el:
                    details["warranty"] = (warranty_el.get_attribute('aria-label') or warranty_el.inner_text()).strip()

                # Specs - Updated selectors from audit
                try:
                    spec_tab = page.query_selector("#specification")
                    if spec_tab: spec_tab.click()
                    page.wait_for_timeout(1000)
                except: pass

                features = page.query_selector_all(".specifications-list, .pdp__tab-info__list__block, #specification .lb_accordeon__item, .product-specifications tr, .key-features-list li")
                for f in features[:25]:
                    key_el = f.query_selector(".specifications-list--left")
                    val_el = f.query_selector(".specifications-list--right")
                    if key_el and val_el:
                        details["specs"].append(f"{key_el.inner_text().strip()}: {val_el.inner_text().strip()}")
                    else:
                        text = f.inner_text().strip().replace('\n', ': ')
                        if text and ':' in text:
                            details["specs"].append(text)
                
                if not details["warranty"] or details["warranty"] == "No Warranty Info":
                     for s in details["specs"]:
                        if "warranty" in s.lower():
                            details["warranty"] = s
                            break

            elif platform == "Vijay Sales":
                page.wait_for_timeout(2000)
                # Rating - Updated selectors
                rating_el = page.query_selector(".product__title--stats p, .avg-rating, .rating-star, .product__title--reviews-star")
                if rating_el: 
                    details["rating"] = rating_el.inner_text().strip().split(' ')[0]
                
                # Shipping / Delivery - Updated selectors
                ship_el = page.query_selector(".delivery__text, .delivery-info, .product-details__delivery")
                if ship_el: details["shipping"] = ship_el.inner_text().strip().replace('\n', ' ')
                
                # Warranty - Vijay Sales (Improved)
                warranty_els = page.query_selector_all(".product-details__spec-item, .spec-item, .panel-list-item")
                for el in warranty_els:
                    txt = el.inner_text().lower()
                    if "warranty" in txt:
                        details["warranty"] = el.inner_text().strip().replace('Warranty', '').strip(': ')
                        break
                
                # Specs - Updated selectors (accordion structure)
                # Ensure all features are shown if there's a button
                try:
                    show_more = page.query_selector("button:has-text('Show all features'), .show-more-features")
                    if show_more: show_more.click()
                except: pass

                spec_container = page.query_selector(".accordionsinglepanel, #specification, .product-specifications, .product-details__specifications")
                if spec_container:
                    rows = spec_container.query_selector_all(".accordion-panel li, tr, .spec-row, .panel-list-item")
                    for row in rows[:25]:
                        # Vijay Sales specs often have keys/values in spans
                        key_el = row.query_selector(".panel-list-key")
                        val_el = row.query_selector(".panel-list-value")
                        if key_el and val_el:
                            details["specs"].append(f"{key_el.inner_text().strip()}: {val_el.inner_text().strip()}")
                        else:
                            txt = row.inner_text().strip().replace('\n', ': ')
                            if txt and ':' in txt:
                                details["specs"].append(txt)
                
                if not details["specs"]:
                    # Fallback for newer VJ layout
                    items = page.query_selector_all(".product-details__spec-item, .spec-item")
                    for item in items[:15]:
                        txt = item.inner_text().strip().replace('\n', ': ')
                        if txt: details["specs"].append(txt)

                # Warranty - Vijay Sales
                for s in details["specs"]:
                    if "warranty" in s.lower():
                        details["warranty"] = s
                        break

            browser.close()
            # Accuracy cleanup
            details["specs"] = [s.strip() for s in details["specs"] if s and (':' in s or len(s) > 15)][:12]
            # Ensure "Standard delivery" isn't returned if better info exists
            if details["delivery_date"] and (not details["shipping"] or details["shipping"] == "Standard delivery"):
                details["shipping"] = details["delivery_date"]
                
            return details
        except Exception as e:
            print(f"[Smart Scraper] Detail Fetch Error: {e}")
            return {"specs": [], "shipping": "Error fetching info", "delivery_date": "", "rating": "N/A"}

def scrape_single_link(url):
    """
    Visits a single product URL to extract its professional title for better searching.
    """
    print(f"[Smart Scraper] Extracting title from: {url[:50]}...")
    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(user_agent="Mozilla/5.0")
            page = context.new_page()
            
            # Block heavy resources for fast title extraction
            page.route("**/*.{png,jpg,jpeg,svg,webp,woff,woff2,css}", lambda route: route.abort())
            
            # Fast timeout (10s) for single link
            page.goto(url, timeout=10000, wait_until="domcontentloaded") 
            
            title = ""
            # Re-ordered: Most specific first! Avoid generic <h1> if possible.
            selectors = [
                "#productTitle", "span#productTitle", "h1#title", # Amazon
                ".B_NuCI", "h1.yhB1nd", "span.B_NuCI", ".VU-ZEz", # Flipkart
                "h1.product-title", "h1.pdp-e-i-head", ".pdp-name", # General/Myntra/Ajio
                "h1" # Fallback
            ]
            
            for selector in selectors:
                try:
                    title_el = page.query_selector(selector)
                    if title_el:
                        text = title_el.inner_text().strip()
                        # Reject if it's just the site name
                        if text.lower() in ["amazon", "flipkart", "reliance digital", "vijay sales", "online shopping"]:
                            continue
                        if len(text) > 5:
                            title = text
                            break
                except: continue
            
            if not title:
                # Improved Fallback with more reliable selectors
                extended_selectors = [
                    "h1.yhB1nd", "span.B_NuCI", ".VU-ZEz", # Flipkart specific
                    "h1#title", "#productTitle",  # Amazon specific
                    "h1.product-title", ".pdp-name" # Generic e-comm
                ]
                for sel in extended_selectors:
                    try:
                        el = page.locator(sel).first
                        if el.is_visible(timeout=1000):
                            text = el.inner_text()
                            if len(text) > 5:
                                title = text.strip()
                                break
                    except: pass

            if not title:
                # Fallback to OG tags and Page Title
                meta_title = page.query_selector('meta[property="og:title"]')
                if meta_title:
                    title = meta_title.get_attribute("content")
                else:
                    title = page.title()
            
            browser.close()
            
            if title:
                title = title.strip()
                # Aggressive cleaning of site titles
                title = re.sub(r'(?i)\s*[:|]\s*(Amazon|Flipkart|Reliance|Vijay Sales|Buy|Online|India|Price).*', '', title)
                return title.strip()
            return ""
        except:
            return ""

if __name__ == "__main__":
    # Performance test
    import time
    start = time.time()
    results = scrape_live("iphone 15")
    elapsed = time.time() - start
    print(f"\n✅ Total Time: {elapsed:.2f} seconds")
    print(f"✅ Results: {len(results)} products")
    for r in results:
        print(f"   - {r['platform']}: {r['name'][:40]}...")
