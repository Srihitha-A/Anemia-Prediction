import os

path = 'scraping/smart_scraper.py'
with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_body = [
    '    with sync_playwright() as p:\n',
    '        try:\n',
    '            # Browser Setup\n',
    '            browser = p.chromium.launch(headless=True)\n',
    '            context = browser.new_context(\n',
    '                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",\n',
    '                viewport={\'width\': 1920, \'height\': 1080}\n',
    '            )\n',
    '            page = context.new_page()\n',
    '            page.set_default_timeout(50000)\n',
    '            \n',
    '            has_cards = False\n',
    '            \n',
    '            # Priority 1: Interactive Home Search\n',
    '            try:\n',
    '                print(f"   [Reliance] Navigating Home...")\n',
    '                page.goto("https://www.reliancedigital.in/", wait_until="domcontentloaded", timeout=30000)\n',
    '                page.wait_for_timeout(4000) # Wait for potential popups\n',
    '                \n',
    '                inp_sel = "input.search-input, input[aria-label*=\'Search\']"\n',
    '                if page.query_selector(inp_sel):\n',
    '                    page.click(inp_sel, force=True)\n',
    '                    page.keyboard.type(query, delay=60)\n',
    '                    page.keyboard.press("Enter")\n',
    '                    \n',
    '                    try:\n',
    '                        page.wait_for_selector(\'.product-card, .sp__product, .listing-item\', timeout=20000)\n',
    '                        has_cards = True\n',
    '                    except:\n',
    '                        pass\n',
    '            except Exception as e:\n',
    '                print(f"   [Reliance] Home search error: {e}")\n',
    '\n',
    '            # Priority 2: Direct URL Fallback\n',
    '            if not has_cards:\n',
    '                url = f"https://www.reliancedigital.in/products?q={query.replace(\' \', \'%20\')}&page_no=1&page_size=12&page_type=number"\n',
    '                print(f"   [Reliance] Direct URL attempt...")\n',
    '                try:\n',
    '                    page.goto(url, wait_until="domcontentloaded", timeout=30000)\n',
    '                    page.wait_for_selector(\'.product-card, .sp__product\', timeout=15000)\n',
    '                    has_cards = True\n',
    '                except: \n',
    '                    pass\n',
    '\n',
    '            if not has_cards:\n',
    '                print(f"   [Reliance] 0 results found.")\n',
    '                browser.close()\n',
    '                return\n',
    '\n',
    '            # Scroll for images\n',
    '            page.evaluate("window.scrollTo(0, 1000)")\n',
    '            page.wait_for_timeout(4000)\n',
    '            page.evaluate("window.scrollTo(0, 2000)")\n',
    '            page.wait_for_timeout(2000)\n',
    '\n',
    '            # Precise Extraction with icon filtering\n',
    '            data = page.evaluate(\"\"\"() => {\n',
    '                const items = [];\n',
    '                const cards = document.querySelectorAll(\'.product-card, .sp__product, .listing-item, [class*="product-card"]\');\n',
    '                \n',
    '                cards.forEach(card => {\n',
    '                    const nameEl = card.querySelector(\'.product-card-title, .sp__name, .name, .product-title\');\n',
    '                    const priceEl = card.querySelector(\'.price-container .price, .sp__price, .price\');\n',
    '                    const linkEl = card.querySelector(\'a[href*="/p/"], a[href*="/product/"], a\');\n',
    '                    \n',
    '                    let imageUrl = null;\n',
    '                    const imgNodes = card.querySelectorAll(\'img\');\n',
    '                    for (let img of imgNodes) {\n',
    '                        let src = img.src || img.getAttribute(\'data-src\') || img.getAttribute(\'srcset\');\n',
    '                        // Exclude icons, theme assets, and SVGs. Prioritize product CDN images.\n',
    '                        if (src && !src.includes(\'theme/assets\') && !src.includes(\'.svg\') && (src.includes(\'products\') || src.includes(\'medias\'))) {\n',
    '                            imageUrl = src;\n',
    '                            break;\n',
    '                        }\n',
    '                    }\n',
    '                    \n',
    '                    if (nameEl && priceEl && linkEl) {\n',
    '                        items.push({\n',
    '                            name: nameEl.innerText.trim(),\n',
    '                            price: priceEl.innerText.trim(),\n',
    '                            image: imageUrl,\n',
    '                            link: linkEl.getAttribute(\'href\')\n',
    '                        });\n',
    '                    }\n',
    '                });\n',
    '                return items;\n',
    '            }\"\"\")\n',
    '\n',
    '            added_count = 0\n',
    '            seen_links = set()\n',
    '            for item in data:\n',
    '                try:\n',
    '                    name = item[\'name\']\n',
    '                    if not any(word in name.lower() for word in query.lower().split() if len(word) \u003e 2):\n',
    '                        continue\n',
    '\n',
    '                    link = item[\'link\']\n',
    '                    if not link.startswith("http"): \n',
    '                        link = "https://www.reliancedigital.in" + (link if link.startswith("/") else "/" + link)\n',
    '                    \n',
    '                    if link in seen_links: continue\n',
    '                    seen_links.add(link)\n',
    '\n',
    '                    price = clean_price(item[\'price\'])\n',
    '                    image = item.get(\'image\')\n',
    '                    if not image or "data:image" in image or ".svg" in image or "theme/assets" in image:\n',
    '                        image = "https://placehold.co/400?text=Reliance"\n',
    '                    elif not image.startswith("http"): \n',
    '                        image = "https://www.reliancedigital.in" + (image if image.startswith("/") else "/" + image)\n',
    '\n',
    '                    with lock:\n',
    '                        results_list.append({\n',
    '                            "name": name, "price": price, "image": image, "link": link,\n',
    '                            "platform": "Reliance Digital", "rating": "", "shipping": ""\n',
    '                        })\n',
    '                        added_count += 1\n',
    '                    if added_count \u003e= 15: break\n',
    '                except: continue\n',
    '\n',
    '            browser.close()\n',
    '            print(f"   [Reliance] Success: Found {added_count} products with images.")\n',
    '        except Exception as e:\n',
    '            print(f"   [Reliance] Scraper error: {e}")\n'
]

start_index = -1
end_index = -1
for i, line in enumerate(lines):
    if 'def scrape_reliance_digital(query, results_list, lock):' in line:
        start_index = i + 4
        break

if start_index != -1:
    for i in range(start_index, len(lines)):
        if 'def scrape_ajio' in lines[i]:
            end_index = i
            break
    if end_index == -1:
        end_index = len(lines)

    lines[start_index:end_index] = new_body
    with open(path, 'w', encoding='utf-8') as f:
        f.writelines(lines)
    print("Successfully updated Reliance scraper with deduplication")
else:
    print("Could not find function start")
