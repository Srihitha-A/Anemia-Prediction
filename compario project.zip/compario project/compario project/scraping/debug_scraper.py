import sys
import threading
import json
import re
import time
from playwright.sync_api import sync_playwright
from scraping.smart_scraper import scrape_amazon, scrape_flipkart, scrape_reliance_digital, scrape_vijay_sales

def test_all_platforms(query):
    lock = threading.Lock()
    print(f"\n{'='*50}")
    print(f"DEBUG: ALL PLATFORMS SEARCH FOR '{query}'")
    print(f"{'='*50}")
    
    # 1. Reliance Digital
    rel_results = []
    print("\n[Reliance Digital] Attempting scrape...")
    scrape_reliance_digital(query, rel_results, lock)
    print(f"   Results found: {len(rel_results)}")
    for r in rel_results[:2]:
        try:
            print(f"   - Name: {r['name']}\n     Price: {r['price']}, Shipping: {r['shipping']}\n")
        except UnicodeEncodeError:
            print(f"   - Name: {r['name'].encode('ascii', 'ignore').decode('ascii')}\n")

    # 2. Amazon
    amz_results = []
    print("\n[Amazon] Attempting scrape...")
    scrape_amazon(query, amz_results, lock)
    print(f"   Results found: {len(amz_results)}")
    for r in amz_results[:2]:
        try:
            print(f"   - Name: {r['name']}\n     Price: {r['price']}, Rating: {r['rating']}\n")
        except UnicodeEncodeError:
            print(f"   - Name: {r['name'].encode('ascii', 'ignore').decode('ascii')}\n")

    # 3. Flipkart
    fk_results = []
    print("\n[Flipkart] Attempting scrape...")
    scrape_flipkart(query, fk_results, lock)
    print(f"   Results found: {len(fk_results)}")
    for r in fk_results[:2]:
        try:
            print(f"   - Name: {r['name']}\n     Price: {r['price']}, Shipping: {r['shipping']}\n")
        except UnicodeEncodeError:
            print(f"   - Name: {r['name'].encode('ascii', 'ignore').decode('ascii')}\n")

def deep_reliance_debug(query):
    print(f"\n{'='*50}")
    print(f"DEEP DEBUG: RELIANCE DIGITAL FOR '{query}'")
    print(f"{'='*50}")
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=["--disable-blink-features=AutomationControlled", "--no-sandbox", "--disable-setuid-sandbox"])
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
            viewport={'width': 1920, 'height': 1080}
        )
        page = context.new_page()
        page.route("**/*.{png,jpg,jpeg,svg,webp,woff,woff2}", lambda route: route.abort())
        
        url = f"https://www.reliancedigital.in/products?q={query}"
        print(f"Visiting {url}...")
        
        try:
            page.goto(url, wait_until="networkidle", timeout=30000)
            page.wait_for_timeout(3000)
            print(f"   Page Title: {page.title()}")
            print(f"   Current URL: {page.url}")
            
            # Check for cards
            has_cards = page.query_selector('.product-card, .sp, .plp-grid-item, .grid, .product-item, .card-wrapper') is not None
            print(f"   Cards found: {has_cards}")
            
            if not has_cards:
                print("   No cards found. Dumping page text snippet:")
                print(f"   {page.evaluate('document.body.innerText.substring(0, 500)')}")
            else:
                names = page.evaluate("""() => 
                    Array.from(document.querySelectorAll('.product-card-title, .sp__name, .name')).slice(0, 5).map(el => el.innerText.trim())
                """)
                print(f"   Top result names: {names}")
                
        except Exception as e:
            print(f"   Debug failed: {e}")
        finally:
            browser.close()

if __name__ == "__main__":
    test_query = "iphone 15"
    if len(sys.argv) > 1:
        test_query = " ".join(sys.argv[1:])
    
    print("Select Mode:")
    print("1: Standard Multi-Platform Search Test")
    print("2: Deep Reliance Digital Interaction Debug")
    
    # In a scripted environment, we might just run both or allow arg override
    # For now, let's run multi-platform and then allow deep debug if reliance fails
    test_all_platforms(test_query)
    
    # If specifically asked or just as a bonus
    # deep_reliance_debug(test_query)
