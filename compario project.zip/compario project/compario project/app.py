from flask import Flask, render_template, request, redirect, session, flash, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_
from werkzeug.security import generate_password_hash, check_password_hash
import re
import os
import sys
import io
from datetime import timedelta
import time
import cv2
import easyocr
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import sqlite3

# Ensure UTF-8 output for Windows Terminal
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
from scraping.smart_scraper import (
    scrape_live, clean_price, scrape_product_details, 
    scrape_single_link, get_category, get_clean_name
)

# Global OCR Reader (Initialized once)
reader = easyocr.Reader(['en'], gpu=False)


app = Flask(__name__)
app.secret_key = "compario_secret_key"
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=31)
app.config['SESSION_REFRESH_EACH_REQUEST'] = True

# Ensure absolute path for the database
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(BASE_DIR, "instance", "compario.db")
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
db = SQLAlchemy(app)

# -------------------- DATABASE MODEL --------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    history = db.relationship('SearchHistory', backref='user', lazy=True)

class Product(db.Model):
    """Database Inventory for Hybrid Fallback"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    price = db.Column(db.Integer, nullable=False)
    image = db.Column(db.String(500))
    link = db.Column(db.String(500))
    platform = db.Column(db.String(50)) # Amazon, Flipkart, Croma, Snapdeal
    search_term = db.Column(db.String(100)) # e.g. "iphone", "boat headphones"
    specifications = db.Column(db.Text, nullable=True) # JSON string
    shipping_info = db.Column(db.String(200), nullable=True)
    rating = db.Column(db.String(50), nullable=True)
    warranty = db.Column(db.String(200), nullable=True)

class SearchHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    query_text = db.Column(db.String(200), nullable=False)
    timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Wishlist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(200), nullable=False)
    price = db.Column(db.String(50))
    platform = db.Column(db.String(50))
    image = db.Column(db.String(500))
    link = db.Column(db.String(500))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(200), nullable=False)
    price = db.Column(db.String(50))
    platform = db.Column(db.String(50))
    image = db.Column(db.String(500))
    link = db.Column(db.String(500))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

def init_db():
    with app.app_context():
        db.create_all()
        
        # Migration: Add warranty column if missing
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(product)")
            columns = [info[1] for info in cursor.fetchall()]
            
            if 'warranty' not in columns:
                print("Adding missing column 'warranty' to 'product' table...")
                cursor.execute("ALTER TABLE product ADD COLUMN warranty VARCHAR(200)")
                conn.commit()
                print("Successfully added 'warranty' column.")
            conn.close()
        except Exception as e:
            print(f"Database migration error: {e}")

init_db()

@app.context_processor
def inject_cart_data():
    cart_count = 0
    cart_total = 0
    if "user" in session:
        try:
            user_obj = User.query.filter_by(username=session["user"]).first()
            if user_obj:
                items = CartItem.query.filter_by(user_id=user_obj.id).all()
                cart_count = len(items)
                total = 0
                for item in items:
                    try:
                        # Use existing clean_price logic
                        price_val = int(float(clean_price(str(item.price))))
                        total += price_val
                    except:
                        pass
                cart_total = total
        except:
            pass
    return dict(cart_count=cart_count, cart_total=cart_total)

# -------------------- ROUTES --------------------
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        identifier = request.form["identifier"]
        password = request.form["password"]
        user = User.query.filter((User.username == identifier) | (User.email == identifier)).first()
        if user and check_password_hash(user.password, password):
            session.permanent = True
            session["user"] = user.username
            flash(f"Welcome back, {user.username}!", "success")
            return redirect("/dashboard")
        flash("Invalid login credentials", "error")
    return render_template("login.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        phone = request.form["phone"]
        password = request.form["password"]
        if User.query.filter((User.username == username) | (User.email == email)).first():
             return "User already exists!"
        hashed = generate_password_hash(password)
        user = User(username=username, email=email, phone=phone, password=hashed)
        db.session.add(user)
        db.session.commit()
        flash("Account created! Please login.", "success")
        return redirect("/")
    return render_template("signup.html")

# Consolidate Price Parsing
def parse_price(p):
    try:
        # Convert to string, clean it, then float, then int
        price_str = clean_price(str(p['price']))
        price = int(float(price_str))
        return price if price > 0 else 9999999
    except: 
        return 9999999

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if "user" not in session: return redirect("/")
    results = None
    if request.method == "POST":
        query = request.form.get("query")
        if query:
            user_obj = User.query.filter_by(username=session["user"]).first()
            if user_obj:
                new_history = SearchHistory(query_text=query, user_id=user_obj.id)
                db.session.add(new_history)
                db.session.commit()
            try:
                # --- NEW: URL Support ---
                is_url = "http" in query.lower() or "www." in query.lower() or ".com" in query.lower() or ".in" in query.lower()
                if is_url:
                    print(f"[Backend Check] URL detected: {query}. Extracting title...")
                    extracted_title = scrape_single_link(query)
                    
                    # Validation: If title is too short or clearly generic/failed (like "Online Shopping"), don't use it.
                    if extracted_title and len(extracted_title) > 3 and "online" not in extracted_title.lower():
                        query = extracted_title
                        print(f"[Backend Check] URL converted to query: '{query}'")
                        # NOW sanitize the title (Allowed dots and hyphens for model names)
                        query = re.sub(r'[^a-zA-Z0-9 ./-]', '', query).strip()
                    else:
                        print(f"[Backend Check] Failed to extract valid title from URL. Falling back to URL parsing.")
                        # Parse URL for keywords
                        # Remove protocol, domain, common query params
                        # Example: https://www.amazon.in/Apple-iPhone-15-128-GB/dp/B0CHX1W1XY -> Apple iPhone 15 128 GB
                        path = query.split('?')[0] # Drop query
                        path = re.sub(r'https?://(www\.)?[a-zA-Z0-9-]+\.[a-z]+/', '', path) # Drop domain
                        
                        # Replace separators with spaces
                        path = re.sub(r'[\./\-_]', ' ', path)
                        
                        # Filter out common junk
                        words = [w for w in path.split() if w.lower() not in ('dp', 'p', 'product', 'buy', 'online') and len(w) > 2]
                        
                        if words:
                            query = " ".join(words[:6]) # Take first 6 significant words
                            print(f"[Backend Check] Extracted from URL path: '{query}'")
                        else:
                            # Last resort: just try searching for the product ID if possible, or fail
                            query = " " 
                else:
                    # Normal search: Sanitize but allow specs chars
                    query = re.sub(r'[^a-zA-Z0-9 ./-]', '', query).strip()
                
                if not query or len(query.strip()) == 0:
                    flash("Invalid search query!", "warning")
                    return render_template("dashboard.html", user=session["user"], results=[], is_post=True)

                print(f"\n[Backend Check] Triggering Live Scraper for: '{query}'")
                results = scrape_live(query)
                print(f"[Backend Check] Scraper returned {len(results)} raw items.")
            except Exception as e:
                print(f"[Backend Check] Scraper Error: {e}")
                results = []
            
            # --- ENHANCED HYBRID FALLBACK ---
            # 1. Platform-Specific Search Validation
            platforms_to_check = ["Amazon", "Flipkart", "Reliance Digital", "Vijay Sales"]
            platforms_found = {res['platform'] for res in results}
            missing_platforms = [p for p in platforms_to_check if p not in platforms_found]
            
            # TRIGGER FALLBACK: If overall results are low (<4) OR key platforms like Reliance are missing
            if len(results) < 4 or "Reliance Digital" in missing_platforms or "Vijay Sales" in missing_platforms:
                if "Reliance Digital" in missing_platforms:
                    print(f"[Fallback] Reliance Digital missing in live results. Checking Database...")
                elif len(results) < 4:
                    print(f"[Fallback] Live results low ({len(results)}). Checking Database...")
                
                query_words = [w for w in query.split() if w and len(w) > 1]
                if query_words:
                    # 1. Strict AND Match (Highest Relevance)
                    search_filter = Product.name.ilike(f"%{query_words[0]}%")
                    for word in query_words[1:]:
                        search_filter &= Product.name.ilike(f"%{word}%")
                    
                    db_results = Product.query.filter(search_filter).limit(30).all()

                    # 2. Flexible OR Match (Fuzzy Fallback) - ONLY if AND returns ZERO
                    if len(db_results) < 3:
                        # Try searching by search_term column which is populated during seed
                        db_results_alt = Product.query.filter(Product.search_term.ilike(f"%{query}%")).limit(20).all()
                        db_results.extend([p for p in db_results_alt if p not in db_results])
                        
                    if len(db_results) == 0:
                        # Final broad attempt
                        broad_filter = Product.name.ilike(f"%{query_words[0]}%")
                        db_results = Product.query.filter(broad_filter).limit(20).all()

                    added_count = 0
                    for p in db_results:
                        if not is_duplicate(p.name, p.link or "#", results, p.platform):
                             # Ensure price is a string for the results list
                            results.append({
                                "name": p.name,
                                "price": str(p.price) if p.price else "0",
                                "image": p.image or "https://placehold.co/400?text=No+Image",
                                "link": p.link or "#",
                                "platform": p.platform or "Database",
                                "rating": p.rating or "",
                                "shipping_info": p.shipping_info or ""
                            })
                            added_count += 1
                    print(f"[Fallback] Added {added_count} items from Database (Total results now: {len(results)}).")
            else:
                print(f"[Backend Check] Live scraper successful with {len(results)} results. Database fallback skipped.")

            if results:
                # Sort results, but keep platform-specific variety if possible
                results.sort(key=parse_price)
            else:
                results = []

            # Final check: If results are too similar (e.g. all Amazon), try to force variety from DB
            platforms_present = {res['platform'] for res in results}
            if len(platforms_present) < 3 and len(results) > 0:
                 # Re-run a quick DB sweep to find other platforms for the SAME query
                 query_words = query.split()
                 if query_words:
                    search_filter = Product.name.ilike(f"%{query_words[0]}%")
                    for word in query_words[1:]:
                        search_filter &= Product.name.ilike(f"%{word}%")
                    db_extras = Product.query.filter(search_filter).limit(20).all()
                    for p in db_extras:
                        if p.platform not in platforms_present:
                            if not is_duplicate(p.name, p.link or "#", results, p.platform):
                                results.append({
                                    "name": p.name,
                                    "price": str(p.price) if p.price else "0",
                                    "image": p.image or "https://placehold.co/400?text=No+Image",
                                    "link": p.link or "#",
                                    "platform": p.platform
                                })
            
            # Final re-sort after injection
            results.sort(key=parse_price)

            # Apply name cleaning for display on cards
            for res in results:
                res['display_name'] = get_clean_name(res['name'])

    return render_template("dashboard.html", user=session["user"], results=results, is_post=(request.method == "POST"))

# Helper for Fuzzy Deduplication
def is_duplicate(new_item_name, new_item_link, current_list, new_item_platform=None):
    """
    Deduplication helper. Only blocks if:
    1. Exact link match.
    2. Same name AND same platform.
    We WANT to see same name if platforms are different for comparison.
    """
    for existing in current_list:
        if new_item_link == existing['link']: return True
        
        # Fuzzy Name match - very strict now to avoid hiding potential comparisons
        n1 = re.sub(r'[^a-z0-9]', '', new_item_name.lower())
        n2 = re.sub(r'[^a-z0-9]', '', existing['name'].lower())
        
        # If same platform AND name is IDENTICAL (or very similar), it's a duplicate
        if new_item_platform and existing.get('platform') == new_item_platform:
            if n1 == n2 or (len(n1) > 20 and len(n2) > 20 and (n1 in n2 or n2 in n1)):
                return True
    return False

@app.route("/search_image", methods=["POST"])
def search_image():
    if "user" not in session: return redirect("/")
    file = request.files.get("image_file")
    if not file or file.filename == "":
        flash("No image selected!", "warning")
        return redirect("/dashboard")

    # Sanitize filename (remove special chars)
    filename = re.sub(r'[^a-zA-Z0-9._-]', '_', file.filename.lower())
    search_query = ""
    
    # Log history simply as Image Upload 
    user_obj = User.query.filter_by(username=session["user"]).first()
    if user_obj:
        try:
            new_history = SearchHistory(query_text="Image Upload Search", user_id=user_obj.id)
            db.session.add(new_history)
            db.session.commit()
        except Exception as db_err:
            print(f"[DB Error] History log failed: {db_err}")
            db.session.rollback()
    
    # --- IMPROVED OCR FOR ALL IMAGE SEARCHES ---
    print(f"[Backend Check] Processing image: {filename}. Running OCR...")
    unique_filename = f"ocr_{int(time.time())}_{filename}"
    try:
        save_dir = os.path.join(BASE_DIR, "static", "uploads")
        if not os.path.exists(save_dir): os.makedirs(save_dir)
        save_path = os.path.join(save_dir, unique_filename)
        file.seek(0)
        file.save(save_path)
        
        ocr_results = reader.readtext(save_path)
        
        # --- Image Enhancement Fallback ---
        if not ocr_results:
            try:
                img = cv2.imread(save_path)
                if img is not None:
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
                    enhanced = clahe.apply(gray)
                    cv2.imwrite(save_path, enhanced)
                    ocr_results = reader.readtext(save_path)
            except: pass

        if ocr_results:
            # 1. Junk patterns for Status Bar and Marketing fluff
            ui_junk_patterns = [
                r'^\d{1,2}:\d{2}$', r'^\d{1,2}%$', r'^[45]G$', r'^LTE$', r'^VoLTE$',
                r'jio', r'airtel', r'vi ', r'bsnl', r'vodafone', r'sim',
                r'cart', r'buy', r'now', r'login', r'signup', r'menu', r'search',
                r'wishlist', r'free', r'delivery', r'check', r'sort', r'filter',
                r'best selling', r'top rated', r'deal of the day', r'limited time', 
                r'new arrival', r'recommended', r'exclusive', r'discount', r'off$',
                r'sponsored', r'ad$', r'flash sale'
            ]
            
            brands = {
                'samsung', 'apple', 'iphone', 'realme', 'narzo', 'redmi', 'xiaomi', 
                'oneplus', 'oppo', 'vivo', 'iqoo', 'poco', 'motorola', 'moto',
                'asus', 'lenovo', 'dell', 'hp', 'acer', 'sony', 'jbl', 'boat', 
                'noise', 'nothing', 'pixel', 'google', 'macbook', 'ipad', 'honor',
                'palo', 'panasonic', 'lg', 'whirlpool', 'haier', 'voltas', 'blue star',
                'nike', 'adidas', 'puma', 'reebok', 'skechers', 'levis', 'zara', 'h&m'
            }

            # New: Patterns for technical specs that shouldn't be in the query
            spec_junk = [
                r'\d+mp', r'\d+gb', r'\d+ram', r'\d+rom', r'\d+mah', r'\d+v', r'\d+w',
                r'quad camera', r'dual sim', r'display', r'screen', r'battery',
                r'processor', r'snapdragon', r'dimensity', r'helio', r'camera'
            ]

            def get_score(res):
                text = res[1].lower().strip()
                bbox = res[0]
                
                # 1. Geometry Analysis
                w = abs(bbox[1][0] - bbox[0][0])
                h = abs(bbox[2][1] - bbox[0][1])
                area = w * h
                
                # 2. Position Analysis (Assume 1000x1000 normalized space roughly)
                # We don't have image dimensions here easily, but we can use relative bbox
                # In EasyOCR, bbox is [tl, tr, br, bl]
                y_center = (bbox[0][1] + bbox[2][1]) / 2
                
                score = h * 2.5 # Height is a strong indicator of prominence
                brand_match = any(b in text for b in brands)
                if brand_match: score *= 5.0

                
                # Spec/Tech Noise Penalty (We want the title, not the specs)
                if any(re.search(sj, text, re.IGNORECASE) for sj in spec_junk):
                    score *= 0.2

                # Marketing Penalty
                marketing_junk = ['best selling', 'top rated', 'deal', 'offer', 'exclusive', 'special', '2025', '2024', 'sponsored', 'buy now']
                if any(mj in text for mj in marketing_junk): score *= 0.1
                
                # Relaxed length penalty (Allow models like S24, Z9)
                is_model = bool(re.search(r'[A-Z]\d{1,2}|iPhone \d{1,2}|M\d{2}|G\d{2}', text, re.I))
                if len(text) < 3 and not is_model: score *= 0.1
                elif is_model: score *= 2.0
                if len(text) > 70: score *= 0.5
                
                return score

            # Filter out junk
            candidates = []
            for res in ocr_results:
                text = res[1].strip()
                if len(text) < 2: continue
                if any(re.search(pat, text, re.IGNORECASE) for pat in ui_junk_patterns):
                    continue
                candidates.append(res)
            
            # Sort candidates by the new heuristic score
            candidates.sort(key=get_score, reverse=True)
            
            if candidates:
                # DEBUG: Print top candidates
                print(f"[OCR Logic] Top candidates after scoring:")
                for c in candidates[:5]:
                    print(f"   - '{c[1]}' (Score: {get_score(c):.1f})")

                # FIXED LOGIC: Better combination of Brand + Model
                top_block = candidates[0]
                top_text = top_block[1].strip()
                top_score = get_score(top_block)
                
                final_parts = [top_text]
                
                # If the top text is JUST a brand (e.g. "Samsung"), we MUST find the model number
                is_just_brand = any(b.lower() == top_text.lower() for b in brands)
                
                if len(candidates) > 1:
                    # Look at next 5 candidates for model parts
                    for res in candidates[1:6]:
                        txt = res[1].strip()
                        txt_score = get_score(res)
                        
                        # Conditions to include:
                        # 1. High score (confidence)
                        # 2. Model-like pattern (contains digits)
                        # 3. We are looking for a model to go with a brand
                        
                        is_model_like = bool(re.search(r'\d', txt))
                        
                        if (is_just_brand and is_model_like) or (txt_score > (top_score * 0.4)):
                            if txt.lower() not in [p.lower() for p in final_parts]: # Avoid dupe
                                # If the brand is already in the final parts, don't add it again if it's separate
                                if not any(txt.lower() == b.lower() for b in brands):
                                    final_parts.append(txt)
                                elif is_just_brand and len(final_parts) == 1:
                                    # Brand found twice? Maybe different blocks. Just keep one.
                                    pass

                combined_name = " ".join(final_parts)
                print(f"[OCR Result] Detected Prominent Text (Scored): {combined_name}")
                
                # Brand/Typo Correction
                corrections = {
                    'icoo': 'iQOO', 'ziotite': 'Z9 Lite', 'zi0': 'Z9', 'zio': 'Z9',
                    'ipone': 'iPhone', 'samsng': 'Samsung', 'motrola': 'Motorola',
                    'real me': 'Realme', 'boat': 'boAt', 'noise': 'Noise',
                    'somp': '', '64mp': '', '108mp': '', '8gb': '', '128gb': '' 
                }
                for typo, correct in corrections.items():
                    if correct == "":
                        combined_name = re.sub(r'\b'+typo+r'\b', '', combined_name, flags=re.IGNORECASE)
                    else:
                        combined_name = re.sub(typo, correct, combined_name, flags=re.IGNORECASE)
                
                # Relaxed sanitization for image search too
                search_query = re.sub(r'[^a-zA-Z0-9 ./-]', '', combined_name).strip()
                search_query = " ".join(search_query.split())
        
        if os.path.exists(save_path): os.remove(save_path)
    except Exception as ocr_err:
        print(f"[OCR Error] {ocr_err}")

    results = []
    if search_query and len(search_query) >= 2:
        try:
            print(f"[Backend Check] Final Search Query: '{search_query}'")
            results = scrape_live(search_query)
        except Exception as e:
            print(f"[Backend Check] Scraper failed: {e}")
        
        # --- ENHANCED HYBRID IMAGE FALLBACK ---
        if len(results) < 4 or "Reliance Digital" not in [r['platform'] for r in results] or "Vijay Sales" not in [r['platform'] for r in results]:
            print(f"[Backend Check] Image results low ({len(results)}) or Reliance missing. Checking Database...")
            query_words = [w for w in search_query.split() if len(w) > 1]
            if query_words:
                search_filter = Product.name.ilike(f"%{query_words[0]}%")
                for word in query_words[1:]:
                    search_filter &= Product.name.ilike(f"%{word}%")
                db_results = Product.query.filter(search_filter).limit(30).all()
                
                if len(db_results) < 3:
                     db_results_alt = Product.query.filter(Product.search_term.ilike(f"%{search_query}%")).limit(20).all()
                     db_results.extend([p for p in db_results_alt if p not in db_results])

                if len(db_results) == 0:
                    broad_filter = Product.name.ilike(f"%{query_words[0]}%")
                    db_results = Product.query.filter(broad_filter).limit(20).all()

                for p in db_results:
                    if not is_duplicate(p.name, p.link or "#", results, p.platform):
                        results.append({
                            "name": p.name, 
                            "price": str(p.price) if p.price else "0",
                            "image": p.image or "https://placehold.co/400?text=No+Image",
                            "link": p.link or "#", 
                            "platform": p.platform or "Database",
                            "rating": p.rating or "",
                            "shipping_info": p.shipping_info or ""
                        })
                print(f"[Fallback] Added items from Database (Total: {len(results)}).")
        else:
            print(f"[Backend Check] Live Image search successful. Database fallback skipped.")

    else:
        print(f"[Backend Check] No valid search query found for image (Query: '{search_query}')")
        flash("Could not detect text in image. Please try a clearer screenshot.", "error")
        results = [] # Ensure empty results to render page blank instead of crashing/redirecting incorrectly
        # We continue to render below, allowing user to see the flash message on the Dashboard


    # --- FINAL SORTING & CLEANUP ---
    if results:
        # Sanitize Live Links too (Redundant but safe)
        for r in results:
            if "amazon.in" in r['link'] and "/dp/" in r['link']:
                asin_match = re.search(r'/dp/([A-Z0-9]{10})', r['link'])
                if asin_match: r['link'] = f"https://www.amazon.in/dp/{asin_match.group(1)}"
        
        results.sort(key=parse_price)
    
    return render_template("dashboard.html", user=session["user"], results=results, is_post=True)



@app.route("/wishlist")
def wishlist():
    if "user" not in session: return redirect("/")
    user_obj = User.query.filter_by(username=session["user"]).first()
    if not user_obj: return redirect("/logout")
    items = Wishlist.query.filter_by(user_id=user_obj.id).all()
    return render_template("dashboard.html", user=session["user"], wishlist_items=items, section="wishlist")

@app.route("/cart")
def cart():
    if "user" not in session: return redirect("/")
    user_obj = User.query.filter_by(username=session["user"]).first()
    if not user_obj: return redirect("/logout")
    items = CartItem.query.filter_by(user_id=user_obj.id).all()
    
    # Calculate Total Price
    total = 0
    for item in items:
        try:
            # Handle possible float strings like "40000.00"
            price_val = int(float(clean_price(str(item.price))))
            total += price_val
        except:
            pass
            
    return render_template("dashboard.html", user=session["user"], cart_items=items, cart_total=total, section="cart")

@app.route("/account", methods=["GET", "POST"])
def account():
    if "user" not in session: return redirect("/")
    user_obj = User.query.filter_by(username=session["user"]).first()
    if not user_obj: return redirect("/logout")
    if request.method == "POST":
        action = request.form.get("action")
        if action == "update_profile":
            new_username = request.form.get("username", "").strip()
            if new_username and new_username != user_obj.username:
                # Check if username already exists
                existing_user = User.query.filter_by(username=new_username).first()
                if existing_user:
                    flash("Username already taken", "error")
                else:
                    user_obj.username = new_username
                    session.permanent = True
                    session["user"] = new_username # Update session
                    flash("Username updated successfully", "success")

            user_obj.email = request.form.get("email")
            user_obj.phone = request.form.get("phone")
            db.session.commit()
            flash("Profile updated", "success")
        elif action == "change_password":
            current_pw = request.form.get("current_password")
            new_pw = request.form.get("new_password")
            if check_password_hash(user_obj.password, current_pw):
                user_obj.password = generate_password_hash(new_pw)
                db.session.commit()
                flash("Password changed", "success")
            else:
                flash("Invalid current password", "error")
        return redirect("/account")
    return render_template("dashboard.html", user=session["user"], user_email=user_obj.email, user_phone=user_obj.phone, section="account")

@app.route("/history")
def history():
    if "user" not in session: return redirect("/")
    user_obj = User.query.filter_by(username=session["user"]).first()
    if not user_obj: return redirect("/logout")
    items = SearchHistory.query.filter_by(user_id=user_obj.id).order_by(SearchHistory.timestamp.desc()).all()
    return render_template("dashboard.html", user=session["user"], history_items=items, section="history")

@app.route("/clear_history")
def clear_history():
    if "user" not in session: return redirect("/")
    user_obj = User.query.filter_by(username=session["user"]).first()
    if user_obj:
        SearchHistory.query.filter_by(user_id=user_obj.id).delete()
        db.session.commit()
        flash("Search history cleared!", "info")
    return redirect("/history")

@app.route("/add_to_wishlist", methods=["POST"])
def add_to_wishlist():
    if "user" not in session: 
        return {"success": False, "message": "Not logged in"}, 401
    
    user_obj = User.query.filter_by(username=session["user"]).first()
    if not user_obj:
        return {"success": False, "message": "User not found"}, 404

    name = request.form.get("name")
    price = request.form.get("price")
    platform = request.form.get("platform")
    image = request.form.get("image")
    link = request.form.get("link")
    
    if not name:
        return {"success": False, "message": "Product name missing"}, 400

    exists = Wishlist.query.filter_by(user_id=user_obj.id, product_name=name).first()
    if not exists:
        new_item = Wishlist(
            product_name=name, 
            price=price, 
            platform=platform, 
            image=image, 
            link=link,
            user_id=user_obj.id
        )
        db.session.add(new_item)
        db.session.commit()
        return {"success": True, "message": f"Added {name} to wishlist!"}
    
    return {"success": True, "message": "Item already in wishlist"}

@app.route("/add_to_cart", methods=["POST"])
def add_to_cart():
    if "user" not in session: 
        return {"success": False, "message": "Not logged in"}, 401
    
    user_obj = User.query.filter_by(username=session["user"]).first()
    if not user_obj:
        return {"success": False, "message": "User not found"}, 404

    name = request.form.get("name")
    price = request.form.get("price")
    platform = request.form.get("platform")
    image = request.form.get("image")
    link = request.form.get("link")
    
    if not name:
        return {"success": False, "message": "Product name missing"}, 400

    exists = CartItem.query.filter_by(user_id=user_obj.id, product_name=name).first()
    if not exists:
        new_item = CartItem(
            product_name=name, 
            price=price, 
            platform=platform, 
            image=image, 
            link=link,
            user_id=user_obj.id
        )
        db.session.add(new_item)
        db.session.commit()
        return {"success": True, "message": f"Added {name} to cart!"}
    
    return {"success": True, "message": "Item already in cart"}

@app.route("/remove_from_wishlist/<int:item_id>")
def remove_from_wishlist(item_id):
    if "user" not in session: return redirect("/")
    user_obj = User.query.filter_by(username=session["user"]).first()
    item = Wishlist.query.filter_by(id=item_id, user_id=user_obj.id).first() if user_obj else None
    if item:
        db.session.delete(item)
        db.session.commit()
        flash("Item removed from wishlist", "info")
    return redirect(url_for('wishlist'))

@app.route("/remove_from_cart/<int:item_id>")
def remove_from_cart(item_id):
    if "user" not in session: return redirect("/")
    user_obj = User.query.filter_by(username=session["user"]).first()
    item = CartItem.query.filter_by(id=item_id, user_id=user_obj.id).first() if user_obj else None
    if item:
        db.session.delete(item)
        db.session.commit()
        flash("Item removed from cart", "info")
    return redirect(url_for('cart'))

@app.route("/api/get_product_details")
def get_product_details():
    url = request.args.get("url")
    platform = request.args.get("platform")
    product_name = request.args.get("name")
    
    if not url or not platform:
        return {"success": False, "message": "Missing URL or Platform"}, 400
    
    # 1. CHECK DATABASE FIRST (Exact URL)
    existing = Product.query.filter_by(link=url).first()
    
    if existing and existing.specifications and existing.specifications != "[]":
        print(f"[API] Found persistent specs for {platform} product (URL match).")
        try:
            import json
            specs = json.loads(existing.specifications)
            return {
                "success": True, 
                "details": {
                    "specs": specs, 
                    "shipping": existing.shipping_info or "Standard Shipping",
                    "rating": existing.rating or "N/A",
                    "warranty": existing.warranty or "No Warranty Info"
                }
            }
        except: pass

    # 2. NAME-BASED FUZZY LOOKUP (Fast second check)
    if product_name:
        clean_name = get_clean_name(product_name)
        words = [w for w in clean_name.lower().split() if len(w) > 2]
        if words:
            # Look for ANY product with similar clean name that has specs
            search_query = Product.query.filter(Product.specifications.isnot(None), Product.specifications != "[]")
            for word in words[:2]: # Very permissive first 2 words
                search_query = search_query.filter(Product.name.ilike(f"%{word}%"))
            
            cached_match = search_query.first()
            if cached_match:
                print(f"[API] Found CACHED specs via name-match: {cached_match.name}", flush=True)
                try:
                    import json
                    specs = json.loads(cached_match.specifications)
                    return {
                        "success": True, 
                        "details": {
                            "specs": specs, 
                            "shipping": cached_match.shipping_info or "Standard Shipping",
                            "rating": cached_match.rating or "N/A",
                            "warranty": cached_match.warranty or "No Warranty Info",
                            "cached": True
                        }
                    }
                except: pass

    # 3. LIVE FETCH
    print(f"[API] Fetching LIVE details for {platform} product...", flush=True)
    try:
        details = scrape_product_details(url, platform)
        
        # PERSIST TO DB: Create product if it doesn't exist, or update existing
        import json
        specs_json = json.dumps(details.get('specs', []))
        
        if not existing:
            # Create a placeholder product to store these specs for the future
            existing = Product(
                name=product_name or "Unknown Product",
                price=0, # Price will be updated next search
                image="",
                link=url,
                platform=platform
            )
            db.session.add(existing)
        
        # Update specs and info
        if details.get('specs'):
            existing.specifications = specs_json
        if details.get('shipping') or details.get('delivery_date'):
            existing.shipping_info = details.get('delivery_date') or details.get('shipping')
        if details.get('rating') and details.get('rating') != 'N/A':
            existing.rating = details.get('rating')
        if details.get('warranty'):
            existing.warranty = details.get('warranty')
            
            
        db.session.commit()
            
        return {"success": True, "details": details}
    except Exception as e:
        print(f"[API] Detail Fetch Error: {e}")
        return {"success": False, "message": str(e)}, 500

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out", "info")
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)
