# Compario Project

A real-time price comparison engine for electronics and fashion.

## Overview
Compario is a powerful web application that aggregates product data from major Indian e-commerce platforms including **Amazon, Flipkart, Reliance Digital, and Vijay Sales**. It provides a unified dashboard for price comparison, detailed specifications, and image-based searching.

## Execution Instructions

Follow these steps to set up and run the project:

### 1. Prerequisites
- **Python 3.11+** installed on your system.
- **Node.js** (optional, for Playwright dependencies).
- **OCR Engine**: Uses `easyocr` (will download models on first run).

### 2. Install Dependencies
Open your terminal in the project directory and run:
```bash
pip install -r requirements.txt
```

### 3. Setup Playwright
The scraper uses Playwright to fetch real-time data. Install the necessary browsers:
```bash
playwright install chromium
```

### 4. Run the Application
Start the Flask development server:
```bash
python app.py
```

### 5. Access the App
Open your web browser and go to:
[http://127.0.0.1:5000](http://127.0.0.1:5000)

---

## Features
- **Real-time Parallel Scraping**: Blazing fast results from Amazon, Flipkart, Reliance Digital, and Vijay Sales using concurrent threads.
- **Advanced Product Details**: Deep-scrapes specifications, warranty, ratings, and shipping info for selected products.
- **Image-to-Search (OCR)**: Upload screenshots of products to automatically detect text and find the best deals.
- **URL Support**: Paste a product URL directly into the search bar to find it on other platforms.
- **Wishlist & Cart**: Save your favorite products and manage your shopping list across different stores.
- **User Authentication**: Secure login and search history tracking.

## Technical Stack
- **Backend**: Flask (Python), SQLAlchemy (SQLite)
- **Scraping**: Playwright, BeautifulSoup
- **Computer Vision**: EasyOCR, OpenCV
- **Frontend**: Vanilla CSS, HTML5, Responsive Design

## Verification
To verify scraper accuracy, run:
```bash
python verify_accuracy.py "product name"
```
